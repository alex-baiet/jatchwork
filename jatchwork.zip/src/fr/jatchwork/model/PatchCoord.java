package fr.jatchwork.model;

public record PatchCoord(Patch patch, int x, int y) {
  
}