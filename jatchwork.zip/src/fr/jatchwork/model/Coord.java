package fr.jatchwork.model;

public record Coord(int x, int y) {

}
